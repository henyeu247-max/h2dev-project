---
name: "dung-video-whatif"
description: "Dựng video YouTube kênh What If (hoạt hình người que kiểu Ifverse) từ thư mục dự án: voice Dgt Auto TTS, ảnh Flow, clip Veo, shot list, SFX, nhạc ra mp4 1080p kèm srt. Gọi /dung-video-whatif."
---

# DỰNG VIDEO WHAT-IF

Nói chuyện với người dùng bằng tiếng Việt, ngắn gọn. Dựng theo đúng shot list; không tự sáng tác lại nội dung.

## 0. Vị trí file

- **Thư mục gốc của kênh:** `D:\whatif` (máy Windows) hoặc `What If` (máy Mac). Kiểm bằng `device_list_dir` thư mục đang kết nối.
- **Dự án:** `<gốc>\projects\<NN>-<slug>\`, gồm:
  - Các file `02-VOICE-<slug>.txt`, `02-VOICE-<slug>-MAP.txt`, `03-SHOTLIST-<slug>.md`, `04-PROMPTS-<slug>.md`.
  - Các thư mục `img\` (I###.png hoặc .jpg), `clips\` (C###.mp4).
  - Voice: Dgt Auto TTS thường tự lưu mp3 vào **thư mục con cùng tên file import** (ví dụ `02-VOICE-<slug>-DGT\1.mp3 … N.mp3`), không phải `voice\`. Tìm cả hai chỗ; tên `1.mp3, 2.mp3…` dùng thẳng, không bắt người dùng đổi tên.
  - Tùy chọn `missing.txt` (danh sách clip bỏ, ví dụ `C007 bỏ`).
- **Bộ dựng:** `<gốc>\Ifverse_Kit\tools\wf_build.py` và `tools\fonts\` (Montserrat, PlexMono, Anton).
- **Âm thanh:** `<gốc>\Ifverse_Kit\sfx\*.wav`, `<gốc>\Ifverse_Kit\music\bed_*.wav`.
- **Đầu ra:** luôn ghi vào `<dự án>\output\`. Không ghi đè file khác của người dùng.

Gọi trống thì lấy dự án mới nhất trong `projects\`. Có nhiều dự án chưa có `output\` thì hỏi một câu chọn dự án nào.

## 1. Kiểm tài nguyên trước khi dựng

1. Dùng `device_list_dir` cho dự án, kèm cờ recursive.
2. Đối chiếu với shot list:
   - Số file voice phải bằng số dòng của file MAP (hoặc của file DGT đã import, nếu là bản DEMO).
   - Mọi `I###` và `C###` xuất hiện trong cột Asset phải có file. Bỏ qua phần `>crop` và `@a-b` khi so tên.
   - Clip có ghi trong `missing.txt` thì không tính là thiếu.
3. Báo một bảng ngắn: có / thiếu cho voice, ảnh, clip.

Xử lý theo tình trạng tài nguyên:

| Tình trạng | Cách xử lý |
|---|---|
| Thiếu clip C | Máy dựng tự dùng ảnh I khung đầu của clip (đọc từ file 04) kèm chuyển động máy. Báo cho người dùng, vẫn dựng. |
| Thiếu ảnh I | Cảnh đó hiện khung giữ chỗ (mã asset + câu thoại). Hỏi người dùng muốn dựng nháp ngay hay chờ đủ. |
| Chưa có voice | Chỉ dựng **animatic**: thêm `--animatic`, thời lượng ước theo số từ, không có giọng. |

## 2. Dựng một đoạn (demo hoặc từng phần)

Khi người dùng chỉ làm voice/ảnh/clip cho một đoạn (ví dụ file `02-VOICE-<slug>-DGT-DEMO.txt` gồm N dòng đầu), tạo một thư mục dự án tạm:
- `02-VOICE-<slug>.txt` cắt đến trước khối V(N+1).
- `02-VOICE-<slug>-MAP.txt` giữ dòng tiêu đề + N dòng đầu.
- `03-SHOTLIST-<slug>.md` chỉ giữ các cảnh thuộc V001…V(N).
- Chép `04-PROMPTS`, các ảnh, clip, voice của đoạn đó vào.

Như vậy video kết thúc gọn ở câu cuối của đoạn. Không dùng `--only` cho trường hợp này (vì `--only` vẫn tính thời gian các khối chưa có voice).

Khi đề xuất demo cho người dùng: chọn đoạn từ đầu đến hết khối ngay sau thẻ TITLE (khoảng 50–70 giây, 20–30 cảnh). Đoạn này có đủ mở đầu lạnh, FLASH, WHIP, GFX, TITLE. Tạo sẵn file DGT-DEMO trong dự án và liệt kê đúng các CH, LOC, I, C cần gen.

## 3. Đưa file lên môi trường làm việc

- Dùng `device_stage_files`, mỗi lần tối đa 50 file và 500 MB. Chia lượt theo nhóm:
  1. Các file chữ của dự án.
  2. Voice.
  3. `img\*`.
  4. `clips\*`.
  5. Toàn bộ `Ifverse_Kit\sfx`, `Ifverse_Kit\music`, `tools\wf_build.py`, `tools\fonts\*`.
- File nằm ở `/mnt/user-data/uploads/<tên thư mục gốc>/...`. Chép sang một thư mục làm việc riêng, ví dụ `~/wf/<slug>/` với `proj/` (có `voice/`, `img/`, `clips/`) và `kit/` (`sfx/`, `music/`). Đặt `fonts/` cạnh `wf_build.py`.
- Dự án đã đưa lên trước đó: kiểm `mtimeMs` bằng `device_list_dir`, chỉ đưa lại file đã đổi.
- Cài thư viện nếu thiếu: `pip install --break-system-packages soundfile pyloudnorm opencv-python-headless pillow numpy`. Phải có `ffmpeg`.

## 4. Dựng

**Bước A — bản nháp nhanh** (960×540, khoảng 40 giây render cho mỗi phút video):
```
python3 wf_build.py --proj ~/wf/<slug>/proj --kit ~/wf/<slug>/kit --out ~/wf/<slug>/out --name <slug> --preview
```

Kiểm bản nháp:
- `build_log.txt`: cảnh thiếu, SFX không tìm thấy, `foley:` bị bỏ qua, cảnh quá ngắn, cảnh báo lệch số file voice.
- Đọc file `qc_sheet_*.jpg` bằng Read: hình đúng cảnh, chữ đồ họa không tràn, không có khung giữ chỗ ngoài ý muốn.
- **Dấu Flow/Veo:** trích một khung giữa mỗi cảnh ảnh/clip từ mp4 (theo `timeline.json`), cắt góc dưới phải, xem có còn ngôi sao Gemini hoặc chữ "Veo" không. Mặc định `--wm-keep 0.90` (giữ 90% trên-trái của mọi ảnh và clip) đã xử lý; nếu còn sót thì giảm xuống 0.88. Người dùng có gói không watermark thì đặt `--wm-keep 1`.
- **Khớp tiếng:** mở `.srt`, câu nào dài dưới 0,4 giây hoặc lệch rõ so với khoảng lặng trong mp3 (`ffmpeg -af silencedetect=n=-38dB:d=0.12`) thì kiểm lại cột Line của shot list.
- **Âm lượng:** `ffmpeg -i out.mp4 -af ebur128 -f null -` phải ra khoảng -14 LUFS.

**Bước B — bản chính** (1920×1080, khoảng 2,5 phút render cho mỗi phút video):
```
nohup python3 wf_build.py --proj … --kit … --out … --name <slug> --split 20 > render.log 2>&1 &
```
- Video dài thì chạy nền, kiểm `render.log` mỗi 3–5 phút. Không gọi lại lệnh khi máy đang render. Đoạn demo dưới 2 phút thì chạy thẳng.
- `--split 20` cắt mp4 thành các phần 20 MB và tạo `GHEP-VIDEO.bat`, vì mỗi file ghi về máy người dùng tối đa khoảng 20–30 MB.

**Xem lại một đoạn:** thêm `--only S040-S075` để xem nhanh một đoạn sau khi sửa (ra file riêng, không ghi đè bản chính).

## 5. Trả kết quả về máy

Ghi bằng `device_commit_files` vào `<dự án>\output\`:
- Các phần `<slug>.mp4.partNN` kèm `GHEP-VIDEO.bat`, hoặc nguyên file mp4 nếu nhỏ hơn 20 MB.
- `<slug>.srt` (phụ đề tiếng Anh để tải lên YouTube làm CC).
- `qc_sheet_*.jpg` và `build_log.txt` nếu người dùng cần.

Ghi qua `stagedPath` phải chép file vào `/mnt/user-data/outputs/...` trước. File nào bị từ chối (lỗi HTTP 400/404) thì gọi `SendUserFile` cho file đó rồi ghi lại bằng `fileUuid`. Đoạn demo thì gửi thêm mp4 qua `SendUserFile` để người dùng xem ngay trong chat.

Nếu đã sửa `wf_build.py`, ghi đè bản mới vào `<gốc>\Ifverse_Kit\tools\wf_build.py`.

Báo người dùng:
- Mở `output\`, bấm đúp `GHEP-VIDEO.bat` (nếu có). File sẽ ghép thành `<slug>.mp4` và tự xóa các phần lẻ.
- Kèm thời lượng video, số cảnh, các cảnh còn dùng khung giữ chỗ hoặc ảnh thay clip, và các SFX `foley:` chưa có.

## 6. Sửa theo góp ý

Người dùng sẽ góp ý theo mã cảnh S###, ví dụ "S045 đổi sang I030>cu", "bỏ chớp trắng ở S120", "nhạc vào trễ quá".

| Góp ý | Cách sửa |
|---|---|
| Đổi hình, hiệu ứng, SFX, nhạc của một cảnh | Sửa đúng ô trong `03-SHOTLIST` ở bản trên môi trường làm việc, rồi ghi file shot list đã sửa về lại máy người dùng (cùng đường dẫn, kèm `expectedMtimeMs`) để hai bản không lệch nhau |
| Nhịp chung (khoảng nghỉ giữa các khối, cắt trước tiếng, độ dài cảnh tối thiểu) | Sửa các hằng số đầu file `wf_build.py`: `BLOCK_GAP` 0.30, `SPEAKER_GAP` 0.18, `LEAD` 0.125, `MIN_SHOT` 0.55 |
| Nhạc to hoặc nhỏ | Mức nhạc nền `-29` LUFS trong hàm `bed_audio`; giọng `-16`; bản cuối `-14` (đo trên tín hiệu stereo) |
| Âm lượng SFX | Bảng `sfx_gain` |
| Khối voice đọc lỗi | Người dùng chạy lại đúng dòng đó trong Dgt Auto TTS, thay file giữ nguyên tên; đưa lên lại riêng file đó rồi dựng lại |

Sau khi sửa, dựng `--only` đoạn liên quan để xem nhanh, rồi dựng lại bản chính.

## 7. Bộ dựng làm gì (để giải thích khi được hỏi)

**Khớp voice:**
- File mp3 thứ N, sắp theo số đầu tiên trong tên file, ứng với dòng N của file MAP, tức khối V tương ứng. Nếu file đã đặt tên V###.mp3 thì dùng thẳng.
- Trong mỗi khối, ranh giới sau câu kết thúc bằng dấu chấm, hỏi, than được gắn vào khoảng lặng thật trong mp3 (điểm giọng bắt đầu nói lại), chọn bằng quy hoạch động theo thứ tự câu và ưu tiên khoảng lặng dài. Ranh giới giữa câu (không dấu câu) chia theo số ký tự giữa hai mốc. Có srt cùng tên thì mốc srt được thêm vào làm ứng viên.
- Hình đổi trước tiếng 0,125 giây (3 khung hình), đúng như đã đo ở kênh đối thủ.
- Giữa các khối nghỉ 0,30 giây, đổi người nói thì 0,18 giây.
- Thẻ tiêu đề được thêm 1,6 giây, màn cuối thêm 4 giây.

**Hình:**
- 1080p, 24 fps, viền đen 62 px trên dưới, viền tối quanh khung, hạt nhiễu nhẹ.
- Mọi ảnh và clip được cắt bỏ 10% mép phải và mép dưới (`--wm-keep 0.90`) để loại dấu ngôi sao Gemini / chữ Veo.
- Ảnh luôn có chuyển động đẩy máy nhẹ (PUSH đẩy mạnh hơn).
- Cắt cận: `cu` ×1,75, `med` ×1,35, `left`/`right` ×1,55.
- Clip lấy đúng đoạn `@a-b`. Nếu clip ngắn hơn cảnh thì chạy chậm (tối đa 0,6×) rồi giữ khung cuối. `SLOW` chạy 0,5×.

**Hiệu ứng:**
- FLASH: khung kem có tia tốc độ, rồi 60% hòa vào cảnh, kèm vòng tròn.
- RING: 3 vòng trắng lan ra trong 12 khung.
- WHIP: lia ngang có nhòe chuyển động trong 5 khung.
- CRACK: chia đôi màn hình bằng vết nứt răng cưa.
- SHAKE: rung 9 khung.
- PLUS/MINUS: biểu tượng góc, giữ đến khi gặp PM-OFF.

**Đồ họa GFX:** title, bigtext (dấu `·` tách dòng, dòng cuối hoặc câu có dấu chấm cuối hiện màu vàng), stat, number (chạy số), list, chart (đường cong quên hoặc timeline), terminal, endcard, score. Chữ tự co cho vừa khung.

**Âm thanh:**
- Giọng chuẩn hóa về -16 LUFS. Nhạc nền về -29 LUFS (thấp hơn giọng khoảng 13 dB, không tự hạ khi có lời), lặp nếu ngắn.
- `bed:` vào dần 1,2 giây; `DROP` tắt nhạc; `RETURN:` bật lại.
- SFX đặt ở đầu cảnh. `flash_hit` canh điểm nổ trùng lúc cắt hình. Tiếng vút đặt sớm hơn 0,12 giây. `foley:` chưa có trong gói thì bỏ qua và ghi vào log.
- Bản cuối chuẩn hóa -14 LUFS (đo stereo), đỉnh dưới -1 dBFS.

## 8. Lỗi thường gặp

| Lỗi | Cách xử lý |
|---|---|
| Log báo "voice files vs blocks" lệch số | Thường do tool xuất thiếu dòng hoặc thừa file cũ, hoặc đang dựng đoạn demo mà chưa cắt file 02/MAP/shot list. Liệt kê tên file voice và nhờ người dùng xóa file thừa hoặc chạy lại dòng thiếu. |
| Câu lệch hình | Kiểm cột Line của shot list có khớp từng chữ với file 02 không, và câu có kết thúc bằng dấu câu không (ranh giới có dấu câu mới được gắn vào khoảng lặng). |
| Còn thấy ngôi sao Gemini hoặc chữ Veo | Giảm `--wm-keep` xuống 0.88. |
| Chữ đồ họa bị tràn | Rút gọn tham số GFX trong shot list (tối đa khoảng 28 ký tự mỗi dòng). |
| Ảnh sai tỉ lệ | Máy tự cắt lấp khung 16:9; ảnh dọc sẽ mất nhiều. Nhắc người dùng gen 16:9. |
| File mp4 quá lớn | Tăng `--split` hoặc giữ nguyên; người dùng chạy `GHEP-VIDEO.bat` để ghép. |