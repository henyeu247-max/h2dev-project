---
name: "script-whatif-en"
description: "Viết kịch bản YouTube \"What If\" tiếng Anh 7-10 phút kiểu hoạt hình người que (phong cách Ifverse) - voice 6 giọng xuất sẵn file import Dgt Auto TTS, shot list khớp từng câu, prompt Flow + Veo, gói tiêu đề thumbnail mô tả, file hướng dẫn gen. Gọi /script-whatif-en."
---

# SCRIPT WHAT-IF (EN) — hoạt hình người que, series 3 phần

Kênh: hoạt hình 2D người que tiếng Anh, thị trường Mỹ/Anh/toàn cầu, ngách "What if you had [năng lực có cơ sở khoa học]?". Đối thủ chuẩn: Ifverse (@IfverseTales). Video 3,7 triệu view của họ dài 7:13; đây là chuẩn nhịp.

Nói chuyện với người dùng bằng **tiếng Việt**. Mọi thứ đưa vào sản xuất (kịch bản, voice, prompt, tiêu đề, mô tả) viết bằng **tiếng Anh**. Không hỏi lại khi đã có đề tài: tự chọn mặc định, ghi một dòng giả định ở đầu câu trả lời rồi làm luôn.

Kịch bản mới hoàn toàn. Không dùng lại cốt truyện của Ifverse (thủ môn cứu bé nhặt bóng ở chung kết World Cup, mẹ bị lừa quỹ đại học, tổ chức bí ẩn mời vào xe đen, hacker "Nice work, Leo"). Học khung, không chép cảnh.

## 1. Đầu vào

- **Gọi trống** `/script-whatif-en` → gợi ý 10 đề tài (mục 9). Chỉ ở chế độ này mới hỏi lại người dùng chọn số.
- **Một năng lực hoặc một câu What If** ("what if you could hear thoughts") → viết trọn Part 1.
- **Transcript hoặc kịch bản đối thủ** dán vào → rút khung, số liệu, nhịp; viết đề tài khác hoặc góc khác hoàn toàn. Không dịch, không viết lại từng đoạn.
- **"Part 2" / "Part 3" của series đã viết** → đọc lại file 01 và 02 của phần trước trong `projects/` (nếu có thư mục kết nối), giữ nguyên nhân vật, tên, màu, năng lực, luật đã thiết lập và ô giọng của từng nhân vật.
- **Tham số tùy chọn:** thời lượng (mặc định 8:30), khung A hoặc B (mục 3, mặc định tự chọn theo đề tài), màu hoodie của nhân vật chính (mặc định chọn một màu chưa dùng ở series trước, tránh đỏ và xanh dương vì trùng Ifverse).

## 2. Đầu ra: 6 file trong một thư mục dự án

Nếu có thư mục người dùng kết nối (thường là `What If`), tạo `What If/projects/<NN>-<slug>/` (NN là số thứ tự tiếp theo, slug viết thường gạch nối, ví dụ `03-hear-thoughts`), kèm sẵn các thư mục con rỗng `voice/ img/ clips/ chars/ locs/ thumb/`. Nếu không có thư mục, giao 6 file qua chat.

1. **`01-SCRIPT-<slug>.txt`**: bản đọc liền mạch. Lời thoại nhân vật đặt trong ngoặc kép "..." ngay trong dòng chảy. Không tiêu đề phần, không markdown, không chú thích. Dòng cuối tách riêng ghi số từ và thời lượng ước tính.
2. **`02-VOICE-<slug>.txt`**: bảng CAST rồi kịch bản cắt thành các khối, để đọc và soát (định dạng ở mục 5). Đi kèm 2 file phụ:
   - **`02-VOICE-<slug>-DGT.txt`**: file import thẳng vào tool Dgt Auto TTS của người dùng.
   - **`02-VOICE-<slug>-MAP.txt`**: bảng dòng tool → V# → ô giọng (+ DROP) cho máy dựng.
3. **`03-SHOTLIST-<slug>.md`**: bảng phân cảnh từng câu, đầu vào chính cho skill `/dung-video-whatif` (định dạng ở mục 6).
4. **`04-PROMPTS-<slug>.md`**: prompt ảnh nhân vật, ảnh bối cảnh, ảnh từng cảnh (Flow, Nano Banana) và prompt clip (Veo 3.1). Định dạng ở mục 7.
5. **`05-PACKAGE-<slug>.md`**: 10 tiêu đề, 3 phương án thumbnail (prompt ảnh và chữ), mô tả YouTube, 20 tag, bình luận ghim, dàn ý 2 phần tiếp theo (mục 8).
6. **`06-HUONG-DAN-GEN-<slug>.md`**: hướng dẫn gen **riêng cho video này**, viết bằng tiếng Việt (mục 10). Có con số cụ thể: bao nhiêu dòng voice theo từng ID giọng, ảnh nhân vật, ảnh bối cảnh, ảnh cảnh, clip; thứ tự làm; tên file; ước tính credit; checklist trước khi gọi `/dung-video-whatif`.

## 3. Khung kịch bản

**Độ dài:** 8:30 tương đương 1.100–1.250 từ, tính cả lời thoại (khoảng 135–145 từ/phút, vì có các nhịp hành động không lời). 7 phút ≈ 950 từ, 10 phút ≈ 1.400 từ. Dưới 90% mục tiêu là thiếu.

**Câu cỡ cảnh quay:** trung bình 5–8 từ, tối đa 16 từ. Mỗi câu là một hình mà người dựng vẽ được. Câu cụt được khuyến khích ("Caught." / "Twenty-one to zero." / "You?"). Dấu "..." dùng để tạo khoảng nghỉ và bất ngờ, tối đa khoảng 25 lần mỗi bài.

**Ngôi kể:** ngôi thứ hai "you", thì hiện tại. Nhân vật chính có tên (do nhân vật phụ gọi) nhưng người kể luôn nói "you". Thỉnh thoảng nhân vật chính nói một câu ngắn của mình.

### Khung A — LADDER (đề tài năng lực cơ thể/giác quan: phản xạ, sức mạnh, thính giác, tốc độ, trí nhớ…)

| Nhịp | Thời gian | Từ | Nội dung bắt buộc |
|---|---|---|---|
| 1. Mở đầu lạnh | 0:00–0:35 | ~80 | 2–3 khoảnh khắc đời thường cho thấy năng lực ngay, không giới thiệu. Một nhân vật phụ thốt câu phản ứng ("How... how did you do that?"). Một con số so sánh: người thường bao nhiêu, còn "you" bao nhiêu. Chốt: "So what if [tiêu đề]?" → thẻ TITLE. |
| 2. Cơ chế | 0:35–1:15 | ~90 | "Here's how it works." Cơ chế ba bước bằng ngôn ngữ trẻ 10 tuổi hiểu. Một điểm bất ngờ khoa học ("Your brain got faster. Your muscles did not."). Một phép thử trực quan có số đo, kèm câu phản ứng của nhà khoa học hoặc bạn bè. |
| 3. Leo thang | 1:15–3:30 | ~320 | 4–6 bậc từ đời thường → xã hội/trường học → game/công việc → thể thao/sân khấu lớn. Mỗi bậc: một con số thật, một khoảnh khắc năng lực, một câu thoại hài của đối thủ hoặc người qua đường. Ít nhất một chuỗi ba nhịp ("Caught. Caught. Caught that too."). Mở bậc lớn nhất bằng "But where it gets really crazy... is [X]." |
| 4. Nổi tiếng và nghi ngờ | 3:30–4:30 | ~140 | Biệt danh công chúng, cáo buộc gian lận, bị kiểm tra, và một luật lệ hoặc giới hạn có thật trong thế giới thực khiến năng lực thành bất lợi ("It's a real rule."). |
| 5. Cái giá | 4:30–5:15 | ~100 | "And there's a cost." 3–4 cái giá về thân thể và tâm lý (đói, đau đầu, chán, cô đơn), kèm một câu nhân vật phụ nói thẳng ("You're bored again, aren't you?"). |
| 6. Cao trào | 5:15–7:15 | ~300 | Nhảy thời gian ("Two years later."). Sân khấu lớn nhất. Một khoảnh khắc chỉ "you" kịp nhìn thấy. Lựa chọn hai vế ngắn ("The trophy... or the stranger."). Chọn theo nhân cách → thua thứ được thấy, thắng thứ quan trọng hơn. Người kể nói một câu ý nghĩa; đám đông hoặc người thân phản ứng. **Đánh dấu tắt nhạc (DROP)** ở nhịp lựa chọn và nhịp hậu quả. |
| 7. Móc nối và kêu gọi | 7:15–8:30 | ~120 | Một nhân vật hoặc tín hiệu mới mở cửa sang Part 2 (lời mời, một lời đe dọa, một năng lực khác xuất hiện), kết bằng một câu ngắn bỏ lửng. Rồi: "So what would you do with [năng lực]? Tell us [câu hỏi cụ thể] in the comments." và "And if you'd have [hành động đạo đức ở cao trào] too... hit like, and subscribe for Part Two." |

### Khung B — PLUS/MINUS (đề tài trí tuệ, tâm lý, xã hội: IQ 500, đọc suy nghĩ, không bao giờ ngủ, nhớ mọi thứ…)

1. **Mở đầu lạnh (~80 từ):** một màn khoe năng lực trong đời thường, đi kèm thang số liệu (người thường 100 → hiếm 140 → giới hạn đo 160 → "You? Five hundred."). Nhân vật phụ hỏi, "you" trả lời tỉnh bơ. Chốt bằng câu tiêu đề → thẻ TITLE.
2. **Lời hứa hai mặt (~40 từ):** "Amazing. And awful. Usually both at once."
3. **4–6 cặp lợi/hại xen kẽ (~420 từ):** mỗi mục mở bằng "Plus:" hoặc "Minus:" (shot list gắn FX PLUS/MINUS). Mỗi mục có một cơ chế khoa học thật (ví dụ dopamine và sự bất ngờ), một tiểu phẩm hai câu thoại, một câu chốt. Có ít nhất một ẩn dụ mạnh (người tỉnh táo trong trại điên).
4. **Lựa chọn sống ẩn (~120 từ):** vì sao "you" giấu năng lực; giá phải trả là không ai biết mình thật sự là ai.
5. **Neo cảm xúc (~120 từ):** một người thân, kể bằng 3–4 hành động hy sinh cụ thể.
6. **Biến cố và hành động có đạo đức (~350 từ):** người thân bị hại bởi kẻ xấu có thật ngoài đời (lừa đảo, tống tiền, bắt nạt). "You" dùng năng lực theo cách không trở thành kẻ xấu; có một mẹo bảo vệ người xem nói thẳng ("Real banks never ask you to..."). Đánh dấu DROP ở nhịp đau nhất. Kết quả có số liệu và một khoảnh khắc ấm áp.
7. **Móc nối và kêu gọi (~120 từ):** một đối thủ ngang tầm lộ diện ("Finally. A real puzzle."), rồi kêu gọi như khung A.

### Luật chung cho cả hai khung

- **Khoa học thật:** 4–6 sự thật kiểm chứng được (thời gian phản xạ, tốc độ bóng, ngưỡng đo IQ, luật thi đấu, cơ chế não). Có công cụ tìm web thì kiểm tra từng con số trước khi viết. Ghi nguồn ngắn trong mục "Science notes" của file 05. Không bịa số; không chắc thì nói định tính.
- **Lời thoại:** 15–30 câu thoại, mỗi câu tối đa 12 từ. Số vai nói không giới hạn, nhưng mọi vai phải gán vào bộ 6 giọng cố định ở mục 5. Mỗi video dùng 4–6 trong 6 giọng; không ô giọng nào đóng hai vai trong cùng một cảnh hội thoại. Tên ngắn, quốc tế, dễ đọc: Leo, Mia, Sam, Nora, Theo, Ava, Coach Dan, Dr. Patel. Đã đặt tên thì giữ nguyên cả series.
- **Tỉ lệ:** người kể chiếm 80–90% số từ. Đám đông, tiếng loa sân vận động, tiếng xì xào không viết thành voice mà ghi `foley:` trong cột SFX của shot list.
- **Số trong file 01 và 02 viết bằng chữ** ("two and a half hundredths", "a hundred and sixty kilometers an hour") để ElevenLabs đọc đúng. Shot list và đồ họa vẫn dùng chữ số.
- **Cấm:** chào hỏi, "in this video", "let's dive in", "fun fact", giới thiệu kênh ở đầu, kêu gọi subscribe giữa bài, dấu ngoặc giải thích, emoji.
- **Giọng điệu:** hài khô kiểu Mỹ, chân thành ở cao trào. Không sến, không thuyết giảng quá hai câu.

## 4. Thiết kế nhân vật và bối cảnh (đưa vào file 04)

**STYLE LOCK** (dán nguyên văn vào cuối mọi prompt ảnh và clip):
`2D flat vector animation still, minimalist stickman characters with a perfectly round solid black head, thin solid black limbs and a simple clothing piece, every face has two small white oval eyes and a short thin white mouth line that shows the emotion (a small calm smile when neutral), no nose, no ears, no hair unless described, soft warm rim light outlining every character, layered flat-shaded background with gentle depth-of-field blur, cinematic lighting with dusk purple and warm orange tones, subtle film grain and soft vignette, clean shapes, calm muted palette, 16:9 widescreen, no text, no captions, no watermark.`

**Khuôn mặt:** mọi nhân vật luôn có **mắt trắng và miệng trắng** (giống đối thủ). Ở trạng thái bình thường là mắt chấm và một nét cười nhỏ; biểu cảm khác thì đổi hình mắt và miệng. Nhân vật đeo kính phải ghi "small white eyes visible through clear round glasses". Câu mô tả mặt luôn đặt **sớm trong prompt**, ngay sau tên nhân vật; chỉ có trong STYLE LOCK ở cuối thì Flow bỏ miệng.

**Bảng nhân vật (Character Bible):** mỗi nhân vật có một dòng cố định, lặp nguyên văn trong mọi prompt có nhân vật đó:
- HERO: stickman, [màu] hoodie với dây rút trắng, có thể thêm một chi tiết nhỏ (tai nghe, đồng hồ).
- Bạn, gia đình, phụ: mỗi người **một món đồ có màu riêng** (mũ lưỡi trai vàng, kính tròn và khăn quàng kem, nơ xanh ngọc, áo blouse trắng và kính tròn, vest đen và mũ phớt). Không hai nhân vật cùng màu.
- Cảnh góc nhìn thứ nhất: "first-person view of the hero's own black silhouette hands with [màu] hoodie sleeves".

**Bối cảnh (LOC):** 4–8 địa điểm mỗi video (bếp, phòng ngủ, đường phố hoàng hôn, sân vận động, phòng thí nghiệm…). Mỗi LOC có một prompt ảnh "master" rộng, không người, dùng làm ảnh tham chiếu cho mọi cảnh ở đó. Địa điểm chỉ xuất hiện một lần thì không cần LOC, prompt ảnh chỉ ghi Ref nhân vật.

## 5. Bộ 6 giọng cố định và định dạng file 02-VOICE

Kênh dùng **một bộ 6 giọng cố định cho mọi video**. Người dùng chọn giọng một lần, gán vào Library của tool Dgt Auto TTS với ID 1–6, và ghi lại trong `What If/voices.txt`. Kịch bản không bao giờ yêu cầu giọng mới, chỉ gán nhân vật vào 6 ô giọng này:

| ID tool | Ô giọng | Dùng cho | Chất giọng |
|---|---|---|---|
| 1 | NARRATOR | người kể, 80–90% video | nam Mỹ 25–35 tuổi, ấm, rõ, hơi tinh nghịch, không trầm kiểu trailer |
| 2 | HERO | nhân vật chính (ít thoại, câu ngắn, tỉnh bơ) | nam trẻ 18–25 tuổi, khô, bình thản |
| 3 | YOUNG_F | em gái, bạn gái, bạn cùng lớp, cô gái trẻ | nữ 15–25 tuổi, sáng, nhanh |
| 4 | ADULT_F | mẹ, cô giáo, phóng viên, bác sĩ nữ | nữ 40–55 tuổi, ấm |
| 5 | ADULT_M | bố, ông, huấn luyện viên, nhà khoa học, bình luận viên, cảnh sát, đối thủ, người qua đường | nam 40–55 tuổi, chắc, có năng lượng |
| 6 | DARK_M | phản diện, kẻ lừa đảo, người bí ẩn, trùm | nam trầm, chậm, lạnh |

**Luật gán vai:**
- Mỗi nhân vật có tên gắn cố định vào một ô suốt series (ví dụ Mia luôn là YOUNG_F).
- Nhân vật chỉ nói một câu thì mượn ô phù hợp nhất. Nếu ô đó đang có nhân vật khác nói trong cùng cảnh, đổi sang ô gần nhất.
- Hai nhân vật cùng ô không được đối thoại trực tiếp với nhau. Nếu cốt truyện bắt buộc, viết lại để một trong hai nói qua lời người kể.
- Không dùng giọng trẻ em. Nhân vật nhỏ tuổi dùng YOUNG_F hoặc HERO, hoặc kể qua lời NARRATOR.

**File `02-VOICE-<slug>.txt` (bản đọc và soát):**

```
CAST (nhân vật → ô giọng)
NARRATOR → NARRATOR
Leo (hero) → HERO
Mia (em gái) → YOUNG_F
Coach Dan → ADULT_M
Stadium announcer → ADULT_M
Man in grey coat → DARK_M
Giọng dùng trong video này: 5/6 (không dùng ADULT_F)
Số khối theo ô: NARRATOR 28 · HERO 4 · YOUNG_F 7 · ADULT_M 9 · DARK_M 3 · tổng 51

=== V001 | NARRATOR ===
A fly buzzes past your face. You don't even think. You just... catch it.

=== V002 | ADULT_M · Sam's dad ===
How... how did you do that?
```

- Tiêu đề khối luôn ghi **ô giọng trước**, tên nhân vật sau dấu `·` (người kể chỉ cần NARRATOR).
- Mỗi lần đổi người nói là một khối mới. Các câu người kể liên tiếp gộp vào một khối, nhưng **tối đa 60 từ hoặc 5 câu**, và luôn ngắt khối ở chỗ đổi bối cảnh hoặc đổi nhịp. Video 8:30 thường có 45–75 khối.
- Văn bản trong khối chỉ là chữ để đọc: không tên nhân vật, không ngoặc kép bao ngoài, không thẻ. Mặc định không dùng thẻ cảm xúc của v3. Nếu người dùng yêu cầu "bản có thẻ" thì cho phép tối đa 10 thẻ: [whispers], [laughs], [sighs], [gasps], [shouting], chỉ ở khối nhân vật.
- Khối đánh dấu `| DROP` sau tên người nói nghĩa là đoạn này tắt nhạc (chỉ để người dựng biết).

**File `02-VOICE-<slug>-DGT.txt` (tool Dgt Auto TTS, import một lượt):**
- Mỗi khối V là đúng **một dòng**, theo thứ tự V001 → cuối: `#<ID> <văn bản>`, có một dấu cách sau ID. Ví dụ `#1 Your best friend can't find her car.` và `#3 Level three? Or four? Theo, help.`
- ID lấy theo bảng ở trên: 1 NARRATOR, 2 HERO, 3 YOUNG_F, 4 ADULT_F, 5 ADULT_M, 6 DARK_M.
- Văn bản trong dòng giống hệt khối trong file 02: không xuống dòng giữa khối, không tên nhân vật, không chữ DROP, không dòng trống, không tiêu đề.
- Lưu UTF-8, xuống dòng kiểu Windows (CRLF) vì tool chạy trên Windows.

**File `02-VOICE-<slug>-MAP.txt`:**
- Dòng đầu là tiêu đề; mỗi dòng sau có dạng `<số dòng> → V### → #ID Ô_GIỌNG (nhân vật) | DROP`.
- Máy dựng dùng file này để gán file mp3 thứ N của tool vào khối V tương ứng. Người dùng giữ nguyên tên file tool xuất ra.

## 6. Định dạng file 03-SHOTLIST (đầu vào của /dung-video-whatif)

Đầu file có 4 dòng tóm tắt: tổng số cảnh, số ảnh I, số clip C, số đồ họa GFX. Sau đó là **một bảng Markdown duy nhất**, cột cố định:

`| S# | V# | Line | Shot | Asset | FX | SFX | Music |`

- **S#**: S001… liên tục. **V#**: khối voice chứa câu đó. **Line**: chép **đúng nguyên văn** câu hoặc cụm từ của file 02 mà cảnh này đi cùng. Cảnh hành động không lời ghi `—`. Người dựng dùng cột này để khớp thời gian.
- **Shot**: WIDE, MED, CU (cận mặt), ECU (cận chi tiết), POV, INSERT (đồ vật), OTS (qua vai), TOP (từ trên xuống), INFO (đồ họa khoa học), TEXT, TERMINAL, SPLIT, END.
- **Asset**:
  - `I012` = ảnh tĩnh, người dựng tự tạo chuyển động (đẩy máy, lớp chiều sâu).
  - `I012>cu` = cắt lại từ ảnh I012 (cu, med, left, right) để ra cảnh mới mà không cần gen thêm.
  - `C007` = clip Veo; `C007@3-5` = đoạn giây 3 đến 5 của clip đó.
  - `GFX:<loại>{tham số}` = đồ họa do máy dựng vẽ, không cần AI. Các loại: `title{line1;line2}`, `number{from;to;unit}`, `stat{text}` (ví dụ "160 km/h = 0.4 s"), `score{A;B}`, `bell{marker}`, `list{items}`, `chart{…}`, `terminal{text}`, `bigtext{text}`, `endcard{line1;line2}`.
- **FX**: FLASH (chớp trắng 1–2 khung kèm tia tốc độ), RING (vòng tròn chậm thời gian), WHIP (lia máy nhanh khi đổi địa điểm), CRACK (chia đôi màn hình bằng vết nứt; Asset ghi `I010\|I011`, dấu gạch đứng phải viết `\|` để không vỡ bảng), PLUS, MINUS (biểu tượng góc màn hình, giữ đến khi có PLUS/MINUS mới hoặc `PM-OFF`), ZOOMNUM (phóng vào chữ số để chuyển cảnh), SHAKE, PUSH (đẩy máy chậm, mặc định cho ảnh tĩnh), SLOW (clip chạy 0,5x). Có thể ghép: `FLASH+RING`.
- **SFX**: tên file trong `Ifverse_Kit/sfx` (whoosh_fast, whoosh_mid, flash_hit, slowmo_ring, impact_light, impact_heavy, impact_punch, ding_high, ting_idea, pop, tick, riser_2s, riser_4s, downer, heartbeat, glitch, phone_ring, phone_vibrate, terminal_typing_24chars, crowd_cheer, cash_register, thud_soft…), hoặc `foley:<mô tả>` khi cần tiếng không có sẵn. Để trống nếu không có.
- **Music**: chỉ ghi khi đổi trạng thái: `bed:wonder` (tương tự cho curious, tension, emotional, triumph, mystery), `DROP` (tắt), `RETURN:<bed>`.

**Mật độ bắt buộc (8:30):**
- 170–200 cảnh, trung bình 2,3–2,8 giây mỗi cảnh, khoảng 0,9 cảnh mỗi câu.
- Không cảnh nào quá 6 giây trừ màn END.
- Mỗi câu mở đầu một cảnh mới; câu dài hơn 10 từ có thể chia thành 2 cảnh.

**Ngân sách tài nguyên (8:30):**

| Loại | Số lượng | Ghi chú |
|---|---|---|
| Ảnh cảnh I | 55–75 ảnh độc nhất | |
| Cảnh cắt lại `>` | 30–90 | Tăng số cảnh mà không tốn credit |
| Clip Veo C | 20–35 | Bắt buộc cho mọi cảnh FLASH, cảnh hành động chính của mỗi bậc, 3 cảnh đầu video, cảnh lựa chọn ở cao trào. Một clip 8 giây có thể cắt thành 2–3 cảnh. |
| GFX | 20–35 | |

**Luật FX:**
- FLASH chỉ dùng cho khoảnh khắc năng lực đỉnh, 6–12 lần mỗi video.
- WHIP dùng ở mọi lần đổi địa điểm.
- TITLE sau mở đầu lạnh; END ở 8–10 giây cuối.
- DROP ít nhất một lần ở cao trào.

## 7. Định dạng file 04-PROMPTS

**A. CHARACTER SHEETS (CH-…):** mỗi nhân vật một prompt, **câu mô tả mặt phải đứng ngay sau dòng nhân vật** (đặt cuối prompt thì Flow bỏ miệng). Mẫu đã test ra miệng ổn định:
```
Character reference sheet of <dòng mô tả nhân vật>. Face design: the round solid black head has two small white oval eyes and, clearly drawn below the eyes, a white curved smile line, like a simple emoji smile in white on black; the white smile is visible in all three views. The same character shown three times side by side: front view, three-quarter view and side view, neutral standing pose, plain warm grey background. <STYLE LOCK>
```
Tên file: `chars/CH-HERO.png`, `chars/CH-MIA.png`…

**B. LOCATION MASTERS (LOC-01…):** ảnh rộng, không người, đúng ánh sáng của cảnh + STYLE LOCK. Tên file: `locs/LOC-01.png`.

**C. SCENE IMAGES (I001…):** mỗi ảnh một khối:
```
I012  ·  dùng cho S034, S035, S036(>cu)  ·  Ref: CH-HERO, CH-SAM, LOC-02
<one English paragraph: shot size + camera angle + who/where + exact pose/action + expression (eyes/mouth) + key props + lighting> + STYLE LOCK
```
- Mô tả tư thế bằng động từ rõ ràng ("leaning back on the chair, one hand already under the falling cup").
- Biểu cảm đặt sớm trong câu, ngay sau tên nhân vật, và luôn có cả mắt lẫn miệng trắng: "narrowed smug eyes and a thin confident smile", "wide round shocked eyes and an open O-shaped mouth".
- Không dùng tên Ifverse, tên người thật, hay logo thương hiệu.
- Không có trường negative; không liệt kê những thứ không muốn (Flow sẽ vẽ chính những thứ đó).
- Muốn chừa chỗ cho đồ họa thì viết "leave clean empty space on the left third".

**D. VIDEO CLIPS (C001…):** Veo 3.1, khung đầu là ảnh I tương ứng:
```
C007  ·  từ ảnh I012  ·  dùng cho S036, S037  ·  Tier: Fast
<what moves, in order, within 8 seconds> Camera: <slow push-in / static / gentle pan left>. Smooth 2D flat vector animation, keep the exact same flat style, colors and character designs as the start frame, no 3D rendering, no new characters, no text, no talking, no lip movement, ambient sound only.
```
- Tier: Quality cho 3 cảnh đầu, mọi cảnh FLASH và cảnh lựa chọn ở cao trào; Fast cho hành động thường; Lite cho chuyển động nhẹ (thử Lite trước với cảnh dễ méo).
- Một clip chỉ một hành động chính. Nhân vật người que dễ bị méo tay chân, nên ưu tiên động tác lớn và rõ (bắt, ném, ngã, chạy, quay đầu).

## 8. File 05-PACKAGE

- **10 tiêu đề:** 6 tiêu đề dạng `What If You [năng lực]?` / `What If Your [thông số] Was 10x [hơn]?` / `What If One [đơn vị] Felt Like [X]?`; 4 tiêu đề biến thể có con số hoặc nghịch lý. Không dùng emoji, không viết hoa toàn bộ, tối đa 60 ký tự. Đánh dấu 1 tiêu đề khuyên dùng.
- **3 phương án thumbnail:**
  - Mỗi phương án có một prompt ảnh riêng: cận mặt nhân vật chính choán nửa phải, mắt nheo tự mãn hoặc mắt tròn hoảng hốt, một tia sáng hình ngôi sao trắng ở một mắt, một vật minh họa nổi bật (đồng hồ, viên đạn, đồng hồ đo IQ), nửa trái để trống tối cho chữ, cộng STYLE LOCK đã bỏ cụm "no text".
  - Phần chữ: 2 dòng, dòng 1 trắng ngắn (con số hoặc chủ đề: "500 IQ", "TOO"), dòng 2 vàng #FFC83D hoặc đỏ #E5484D có dấu chấm cuối ("SLOW.", "SOLVED."). Font Montserrat ExtraBold hoặc Anton, viền đen 8–10 px, đổ bóng nhẹ.
  - Phần 2 và 3 thêm nhãn đỏ "PART 2" / "FINAL PART" ở góc.
- **Mô tả:**
  - Dòng 1–2 để trống chỗ link Part 2/3 ("▶ PART 2 is out: …", người dùng tự điền).
  - 2–3 câu tóm tắt kết thúc bằng một nút thắt.
  - Chapters 6–8 mốc, ước từ số từ.
  - Câu hỏi bình luận.
  - Câu "Subscribe for more What Ifs…".
  - "Science notes:" 3–5 sự thật kèm nguồn ngắn.
  - Hashtag: #whatif #animation #stickman + 2 hashtag riêng của đề tài.
- **20 tag**, phân cách bằng dấu phẩy, dưới 450 ký tự.
- **Bình luận ghim:** một câu hỏi chọn A/B liên quan đến lựa chọn ở cao trào.
- **Series:** dàn ý Part 2 và Part 3, mỗi phần 5 gạch đầu dòng, tiêu đề dự kiến dạng `What If You Used [năng lực] to [mục tiêu]? (Part 2)`. Part 3 có tiêu đề riêng mạnh hơn.

## 9. Chế độ gợi ý đề tài

10 đề tài, mỗi đề tài một dòng: tiêu đề hoàn chỉnh · khung A/B · cơ sở khoa học neo · bậc thang hoặc cặp lợi/hại hấp dẫn nhất · ý tưởng cao trào đạo đức (một câu) · tiềm năng series (1–3 sao). Chấm điểm và xếp hạng theo bốn tiêu chí: dễ hình dung bằng hình, con số so sánh gây sốc, có thể tạo lựa chọn đạo đức, có thể nối thành 3 phần.

Tránh đề tài Ifverse đã làm: reaction time, one second felt like ten, 500 IQ. Có công cụ tìm web thì quét kênh @IfverseTales để cập nhật danh sách trước khi đề xuất.

Kho ý tưởng gợi mở (không bắt buộc): perfect memory, hearing 10x, never sleeping, seeing 1 second into the future, feeling no pain, reading micro-expressions, 10x strength, smelling like a dog, stopping time for 3 seconds, speaking every language, perfect pitch, seeing infrared, never forgetting a face, aging backwards, living 1 day per year.

## 10. File 06-HUONG-DAN-GEN (tiếng Việt, riêng cho video này)

Theo đúng thứ tự:

1. **Tóm tắt số lượng:** số dòng voice (chia theo ID giọng), số CH, LOC, I, C; ước tính credit Flow theo tier (ghi rõ là ước tính, nhắc kiểm bảng giá hiện tại); thời gian dự kiến.
2. **Cây thư mục dự án** với tên file chính xác.
3. **Voice bằng Dgt Auto TTS (ElevenLabs):**
   - Bảng ID 1–6 → ô giọng → nhân vật trong tập này → số dòng của mỗi ID.
   - Các bước:
     1. Import `02-VOICE-<slug>-DGT.txt`; kiểm cột Voice # ra 1–6.
     2. Bật "Tự động tạo Srt", bấm Start.
     3. Đưa toàn bộ mp3 (và srt) vào `voice/`, giữ tên gốc.
     4. Không cần Join Mp3.
   - Thông số từng ID lấy theo `What If/voices.txt`.
   - Ghi rõ số dòng của các câu quan trọng cần nghe lại, nhân vật nào đang dùng chung ID cần chỉnh Speed, và các con số phải kiểm cách đọc.
4. **Flow, bước 1 (bắt buộc làm trước):**
   - Gen CH-…, chọn bản đẹp nhất **có đủ 2 mắt trắng và miệng trắng**, lưu vào `chars/` và chép sang `What If/series-assets/<series>/`.
   - Dán prompt vào khung trống mới; không bấm gen lại từ ảnh cũ trong lịch sử (Flow sẽ dùng lại prompt cũ).
   - Gen LOC-…, lưu vào `locs/`.
   - Nếu series đã có CH thì dùng lại, không gen mới.
5. **Flow, bước 2:**
   - Gen I001… với các ảnh Ref làm thành phần tham chiếu (ingredients), khung 16:9.
   - Mỗi prompt gen 2–4 biến thể, chọn bản giữ đúng nhân vật, lưu `img/I012.png`.
   - Cách sửa lỗi thường gặp: nhân vật bị vẽ mặt người thật, mất mắt hoặc mất miệng (gen lại bằng prompt mới trong khung trống, không bấm gen lại từ lịch sử; hoặc sửa ảnh: "Draw a clearly visible white curved smile, like an emoji smile, below the two white eyes on each black head. Keep everything else exactly the same."), ra chữ trong ảnh, phong cách lệch sang 3D, sai màu áo.
6. **Flow, bước 3:**
   - Gen C001… bằng Veo 3.1 với ảnh I tương ứng làm khung đầu, đúng tier.
   - Lưu `clips/C007.mp4`.
   - Nếu clip méo thì gen lại ở Lite trước, hoặc bỏ clip và ghi vào `missing.txt` (máy dựng dùng ảnh I thay thế).
7. **Thumbnail:** gen 3 ảnh vào `thumb/`, ghép chữ trên Canva theo thông số ở file 05.
8. **Checklist trước khi dựng:**
   - Đủ số file mp3 từ Dgt Auto TTS (bằng số dòng file DGT), đủ I, đủ C (hoặc đã ghi clip nào bỏ).
   - Tên file ảnh và clip đúng mẫu.
   - Gọi `/dung-video-whatif projects/<NN>-<slug>`.

## 11. Tự kiểm trước khi giao

- [ ] Số từ nằm trong ±10% mục tiêu; câu trung bình 5–8 từ, không câu nào quá 16 từ.
- [ ] Đủ các nhịp của khung đã chọn và đúng thứ tự; có TITLE sau mở đầu lạnh, có "Here's how it works" (khung A) hoặc "Amazing. And awful." (khung B).
- [ ] Có 4–6 sự thật khoa học, đã kiểm hoặc diễn đạt an toàn; có câu "It's a real rule." hoặc tương đương.
- [ ] Cao trào có lựa chọn hai vế, chọn theo nhân cách, có ít nhất một DROP.
- [ ] Phần kết có móc Part 2, câu hỏi bình luận cụ thể, lời kêu gọi gắn với hành động đạo đức.
- [ ] Mọi khối trong 02 thuộc đúng một trong 6 ô giọng; bảng CAST đầy đủ; không có hai nhân vật cùng ô đối thoại trực tiếp; người kể chiếm 80–90% số từ.
- [ ] File 01 và 02 sạch: không ngoặc giải thích, không markdown, số viết bằng chữ; mọi khối 02 không quá 60 từ.
- [ ] File DGT có số dòng đúng bằng số khối V, mỗi dòng bắt đầu `#1`–`#6` khớp ô giọng; file MAP khớp từng dòng.
- [ ] Ghép toàn bộ chữ của file 02 lại thì khớp từng chữ với file 01 (bỏ dấu ngoặc kép).
- [ ] Mọi câu trong file 02 đều xuất hiện trong cột Line của shot list, đúng thứ tự.
- [ ] Tổng số cảnh và ngân sách I/C/GFX nằm trong khoảng ở mục 6; mọi FLASH có C và SFX flash_hit; mọi lần đổi địa điểm có WHIP và whoosh.
- [ ] Mọi Asset I và C trong shot list đều có prompt trong file 04 (đếm và so khớp); mọi prompt I có dòng Ref; mọi prompt C ghi ảnh I khung đầu.
- [ ] Mọi prompt CH dùng đúng mẫu ở mục 7A (câu "Face design… emoji smile…" đứng ngay sau dòng nhân vật); mọi prompt I có nhân vật đều mô tả mắt và miệng sớm trong câu; nhân vật giữ đúng một dòng mô tả cố định ở mọi prompt; màu hoodie của nhân vật chính không phải đỏ hoặc xanh dương.
- [ ] Không dùng lại cảnh hoặc cốt truyện của Ifverse; không có tên kênh đối thủ trong prompt.
- [ ] File 06 có số lượng thật của video này, không phải số mẫu.