#!/usr/bin/env python3
"""wf_build.py — What-If channel auto editor (Ifverse style).

Reads a project folder produced by /script-whatif-en:
  02-VOICE-*.txt, 02-VOICE-*-MAP.txt, 03-SHOTLIST-*.md, voice/, img/, clips/, missing.txt
and the sound kit (Ifverse_Kit/sfx, Ifverse_Kit/music). Renders a 1920x1080 24fps mp4
with letterbox, push-ins, crops, clip segments, FLASH / RING / WHIP / CRACK / SHAKE / PLUS-MINUS,
generated GFX cards, voice + music bed (with DROP/RETURN) + SFX, and an .srt.

Usage:
  python3 wf_build.py --proj PROJECT_DIR --kit KIT_DIR --out OUT_DIR [--preview] [--animatic] [--only S001-S040]
"""
import argparse, glob, json, math, os, re, subprocess, sys, random
import numpy as np, cv2
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import soundfile as sf

HERE = os.path.dirname(os.path.abspath(__file__))
FONT_DIR = os.path.join(HERE, 'fonts')
FPS = 24
SR = 48000
LEAD = 0.125          # picture cuts ~3 frames before the line starts
BLOCK_GAP = 0.30      # silence between voice blocks
SPEAKER_GAP = 0.18    # shorter gap when the speaker changes (dialogue ping-pong)
MIN_SHOT = 0.55       # shortest allowed shot
WORDS_PER_SEC = 2.45  # animatic voice estimate

# ---------------------------------------------------------------- parsing
def read(p): return open(p, encoding='utf-8-sig').read()

def find(proj, pattern):
    g = sorted(glob.glob(os.path.join(proj, pattern)))
    return g[0] if g else None

def parse_voice(path):
    txt = read(path)
    blocks = []
    for m in re.finditer(r'^=== (V\d+) \| ([A-Z_]+)(?: · ([^|=]*?))?( \| DROP)? ===\s*\n(.+?)(?=\n\s*\n|\n===|\Z)', txt, re.M | re.S):
        blocks.append(dict(id=m.group(1), slot=m.group(2), who=(m.group(3) or '').strip(), drop=bool(m.group(4)),
                           text=' '.join(m.group(5).split())))
    return blocks

def parse_shotlist(path):
    rows = []
    for line in read(path).splitlines():
        if not line.startswith('| S'): continue
        cells = [c.strip().replace('\\|', '|') for c in re.split(r'(?<!\\)\|', line)[1:-1]]
        if len(cells) < 8: cells += [''] * (8 - len(cells))
        s, v, text, shot, asset, fx, sfx, music = cells[:8]
        rows.append(dict(id=s, v=v, line=text, shot=shot, asset=asset,
                         fx=[f for f in re.split(r'[+ ,]+', fx) if f], sfx=sfx, music=music))
    return rows

def parse_map(path):
    m = {}
    if not path: return m
    for line in read(path).splitlines():
        mm = re.match(r'\s*(\d+)\s*→\s*(V\d+)', line)
        if mm: m[int(mm.group(1))] = mm.group(2)
    return m

# ---------------------------------------------------------------- audio helpers
def load_audio(path):
    """decode any audio to mono float32 @48k via ffmpeg"""
    out = subprocess.run(['ffmpeg', '-v', 'error', '-i', path, '-ac', '1', '-ar', str(SR), '-f', 'f32le', '-'],
                         capture_output=True, check=True).stdout
    return np.frombuffer(out, np.float32).copy()

def load_stereo(path):
    out = subprocess.run(['ffmpeg', '-v', 'error', '-i', path, '-ac', '2', '-ar', str(SR), '-f', 'f32le', '-'],
                         capture_output=True, check=True).stdout
    return np.frombuffer(out, np.float32).reshape(-1, 2).copy()

def trim_silence(y, thr=0.004):
    idx = np.where(np.abs(y) > thr)[0]
    if len(idx) == 0: return y
    a = max(0, idx[0] - int(0.03 * SR)); b = min(len(y), idx[-1] + int(0.06 * SR))
    return y[a:b]

def pauses(y, min_len=0.10):
    """return list of (start,end) seconds of low-energy regions inside speech"""
    hop = int(0.01 * SR)
    n = len(y) // hop
    if n < 3: return []
    e = np.sqrt(np.mean(y[:n * hop].reshape(n, hop) ** 2, 1) + 1e-12)
    thr = max(np.percentile(e, 20) * 1.8, e.max() * 0.04)
    low = e < thr
    res, s = [], None
    for i, l in enumerate(low):
        if l and s is None: s = i
        if not l and s is not None:
            if (i - s) * 0.01 >= min_len and s > 0: res.append((s * 0.01, i * 0.01))
            s = None
    return res

def lufs(y):
    try:
        import pyloudnorm as pyln
        return pyln.Meter(SR).integrated_loudness(y.astype(np.float64))
    except Exception:
        r = np.sqrt(np.mean(y ** 2) + 1e-12); return 20 * np.log10(r) - 0.7

# ---------------------------------------------------------------- voice mapping & timing
def collect_voice_files(vdir):
    fs = [f for f in glob.glob(os.path.join(vdir, '*')) if f.lower().endswith(('.mp3', '.wav', '.m4a', '.ogg'))]
    named = {}
    for f in fs:
        m = re.match(r'^(V\d{3})', os.path.basename(f))
        if m: named[m.group(1)] = f
    if named: return named, 'named'
    def key(f):
        m = re.search(r'\d+', os.path.basename(f))
        return (int(m.group()) if m else 10 ** 9, os.path.basename(f))
    return sorted(fs, key=key), 'ordered'

def srt_cues(path):
    if not path or not os.path.exists(path): return []
    cues = []
    for m in re.finditer(r'(\d\d):(\d\d):(\d\d)[,.](\d{3})\s*-->', read(path)):
        h, mi, s, ms = map(int, m.groups()); cues.append(h * 3600 + mi * 60 + s + ms / 1000)
    return cues

def split_block(audio_len, y, lines, cue_starts):
    """return start offsets (s) for each line inside a block.
    Ranh gioi sau cau ket thuc bang . ? ! ... duoc gan vao khoang lang (diem bat dau noi lai);
    ranh gioi giua cau (khong dau cau) chia theo so ky tu giua hai moc."""
    n = len(lines)
    if n == 1: return [0.0]
    weights = [max(1, len(re.sub(r'[^A-Za-z0-9]', '', l))) for l in lines]
    tot = sum(weights)
    expected, acc = [], 0
    for w in weights[:-1]:
        acc += w; expected.append(acc / tot * audio_len)
    punct = [k for k in range(n - 1) if re.search(r'[.?!\u2026:;"]\s*$', lines[k].strip())]
    pz = [(a, b) for a, b in (pauses(y, 0.15) if y is not None else []) if b < audio_len - 0.2 and a > 0.15]
    pz += [(c - 0.01, c + 0.01) for c in cue_starts if 0.3 < c < audio_len - 0.3]
    pz.sort()
    anchors = {}
    P, Z = len(punct), len(pz)
    if P and Z >= P:
        # DP: gan tung ranh gioi co dau cau vao mot khoang lang theo thu tu; uu tien lang dai, gan vi tri du kien
        def cost(k, z):
            a, b = pz[z]
            return abs((a + b) / 2 - expected[punct[k]]) / max(audio_len, 1) - 0.6 * min(b - a, 0.8)
        INF = 1e9
        f = [[INF] * (Z + 1) for _ in range(P + 1)]
        for z in range(Z + 1): f[0][z] = 0.0
        for k in range(1, P + 1):
            for z in range(k, Z + 1):
                f[k][z] = min(f[k][z - 1], f[k - 1][z - 1] + cost(k - 1, z - 1))
        k, z = P, Z
        while k > 0:
            if z > k and abs(f[k][z] - f[k][z - 1]) < 1e-12: z -= 1; continue
            anchors[punct[k - 1]] = pz[z - 1][1] - 0.02; k -= 1; z -= 1
    bounds = [(-1, 0.0)] + sorted(anchors.items()) + [(n - 1, audio_len)]
    res = [0.0] * (n - 1)
    for (ka, ta), (kb, tb) in zip(bounds, bounds[1:]):
        if kb < n - 1: res[kb] = tb
        segt = sum(weights[ka + 1:kb + 1]); acc = 0
        for q in range(ka + 1, kb):
            acc += weights[q]; res[q] = ta + (tb - ta) * acc / segt
    out, last = [0.0], 0.0
    for t in res:
        t = max(t, last + 0.35); out.append(t); last = t
    return out

# ---------------------------------------------------------------- graphics helpers
class Fonts:
    def __init__(self):
        self.cache = {}
    def get(self, kind, size):
        k = (kind, size)
        if k not in self.cache:
            if kind == 'mono': f = ImageFont.truetype(os.path.join(FONT_DIR, 'PlexMono.ttf'), size)
            elif kind == 'anton': f = ImageFont.truetype(os.path.join(FONT_DIR, 'Anton.ttf'), size)
            else:
                f = ImageFont.truetype(os.path.join(FONT_DIR, 'Montserrat.ttf'), size)
                try: f.set_variation_by_axes([{'black': 900, 'bold': 800, 'semi': 600, 'reg': 500}[kind]])
                except Exception: pass
            self.cache[k] = f
        return self.cache[k]
FONTS = Fonts()

def text_size(d, txt, font, spacing=0):
    if spacing == 0:
        b = d.textbbox((0, 0), txt, font=font); return b[2] - b[0], b[3] - b[1], b[1]
    w = sum(d.textlength(ch, font=font) for ch in txt) + spacing * (len(txt) - 1)
    b = d.textbbox((0, 0), txt, font=font); return int(w), b[3] - b[1], b[1]

def draw_text(img, xy, txt, font, fill, spacing=0, anchor='mm', glow=None, shadow=True):
    """draw text centred at xy with optional letter spacing, glow and drop shadow (RGBA image)"""
    d = ImageDraw.Draw(img)
    w, h, top = text_size(d, txt, font, spacing)
    x0 = xy[0] - w / 2 if anchor[0] == 'm' else xy[0]
    y0 = xy[1] - h / 2 - top if anchor[1] == 'm' else xy[1] - top
    layer = Image.new('RGBA', img.size, (0, 0, 0, 0)); ld = ImageDraw.Draw(layer)
    def put(dd, ox, oy, col):
        if spacing == 0: dd.text((x0 + ox, y0 + oy), txt, font=font, fill=col)
        else:
            x = x0 + ox
            for ch in txt:
                dd.text((x, y0 + oy), ch, font=font, fill=col); x += dd.textlength(ch, font=font) + spacing
    if glow:
        g = Image.new('RGBA', img.size, (0, 0, 0, 0)); put(ImageDraw.Draw(g), 0, 0, glow)
        g = g.filter(ImageFilter.GaussianBlur(14)); img.alpha_composite(g); img.alpha_composite(g)
    if shadow:
        s = Image.new('RGBA', img.size, (0, 0, 0, 0)); put(ImageDraw.Draw(s), 0, 6, (0, 0, 0, 170))
        s = s.filter(ImageFilter.GaussianBlur(6)); img.alpha_composite(s)
    put(ld, 0, 0, fill); img.alpha_composite(layer)
    return w, h

def fit(kind, size, txt, maxw, spacing=0):
    d = ImageDraw.Draw(Image.new('RGBA', (8, 8)))
    while size > 12:
        f = FONTS.get(kind, size)
        if text_size(d, txt, f, spacing)[0] <= maxw: return f
        size = int(size * 0.92)
    return FONTS.get(kind, size)

def ease(t): return 1 - (1 - min(max(t, 0), 1)) ** 3
def pop(t):   # overshoot pop 0->1
    t = min(max(t, 0), 1); return 1 + 2.2 * (t - 1) ** 3 + 1.2 * (t - 1) ** 2

class Look:
    """global finishing: letterbox, vignette, grain"""
    def __init__(self, W, H):
        self.W, self.H = W, H
        self.bar = int(round(62 * H / 1080))
        yy, xx = np.mgrid[0:H, 0:W]
        r = np.sqrt(((xx - W / 2) / (W / 2)) ** 2 + ((yy - H / 2) / (H / 2)) ** 2)
        self.vig = (1 - 0.38 * np.clip(r - 0.55, 0, 1) ** 1.6)[..., None].astype(np.float32)
        rng = np.random.default_rng(3)
        self.grain = [rng.normal(0, 2.6, (H, W, 1)).astype(np.float32) for _ in range(4)]
    def apply(self, f, i):
        f = f.astype(np.float32) * self.vig + self.grain[(i // 3) % 4]
        f = np.clip(f, 0, 255).astype(np.uint8)
        f[:self.bar] = 0; f[self.H - self.bar:] = 0
        return f

# Flow/Veo dong dau (ngoi sao Gemini, chu Veo) nam o goc duoi phai: giu phan tren-trai WM_KEEP cua anh/clip
WM_KEEP = 0.90
def wm_cut(im):
    if WM_KEEP >= 1: return im
    h, w = im.shape[:2]
    return im[:int(h * WM_KEEP), :int(w * WM_KEEP)]

# ---------------------------------------------------------------- renderer
class Renderer:
    def __init__(self, W, H, proj, missing):
        self.W, self.H = W, H
        self.proj = proj
        self.missing = missing
        self.img_cache = {}
        self.prev_frame = np.zeros((H, W, 3), np.uint8)
        self.pm_state = None
        self.prev_is_gfx = False
        self.gfx_bg = None
        self.flash_card = self.make_flash()
        self.navy = self.make_navy()

    # ---------- base assets
    def find_asset(self, code):
        if code.startswith('I'):
            for ext in ('.png', '.jpg', '.jpeg', '.webp'):
                p = os.path.join(self.proj, 'img', code + ext)
                if os.path.exists(p): return p
        if code.startswith('C'):
            for ext in ('.mp4', '.mov', '.webm'):
                p = os.path.join(self.proj, 'clips', code + ext)
                if os.path.exists(p): return p
        return None

    def load_img(self, p):
        if p not in self.img_cache:
            im = cv2.imread(p, cv2.IMREAD_COLOR)
            im = wm_cut(im)
            # cover-fit to 16:9 at 2x height for crop headroom
            th = self.H * 2 if self.H < 1000 else int(self.H * 1.6)
            tw = th * 16 // 9
            h, w = im.shape[:2]; s = max(tw / w, th / h)
            im = cv2.resize(im, (int(w * s + 0.5), int(h * s + 0.5)), interpolation=cv2.INTER_CUBIC)
            y0 = (im.shape[0] - th) // 2; x0 = (im.shape[1] - tw) // 2
            self.img_cache[p] = im[y0:y0 + th, x0:x0 + tw]
        return self.img_cache[p]

    CROPS = {'': (1.0, .5, .5), 'cu': (1.75, .5, .42), 'med': (1.35, .5, .46), 'left': (1.55, .3, .5), 'right': (1.55, .7, .5)}

    def view(self, src, zoom, cx, cy):
        H, W = self.H, self.W
        sh, sw = src.shape[:2]
        vw, vh = sw / zoom, sh / zoom
        x0 = min(max(cx * sw - vw / 2, 0), sw - vw); y0 = min(max(cy * sh - vh / 2, 0), sh - vh)
        M = np.array([[W / vw, 0, -x0 * W / vw], [0, H / vh, -y0 * H / vh]], np.float32)
        return cv2.warpAffine(src, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)

    def placeholder(self, code, line, p):
        img = Image.fromarray(cv2.cvtColor(self.navy, cv2.COLOR_BGR2RGB)).convert('RGBA')
        draw_text(img, (self.W / 2, self.H * 0.40), code, FONTS.get('black', int(self.H * 0.11)), (255, 200, 61, 255), spacing=4)
        txt = line if line and line != '—' else ''
        if txt:
            words, lines, cur = txt.split(), [], ''
            for w in words:
                if len(cur + ' ' + w) > 46: lines.append(cur); cur = w
                else: cur = (cur + ' ' + w).strip()
            lines.append(cur)
            for k, l in enumerate(lines[:3]):
                draw_text(img, (self.W / 2, self.H * (0.58 + 0.07 * k)), l, FONTS.get('semi', int(self.H * 0.04)), (230, 232, 240, 255))
        return cv2.cvtColor(np.array(img.convert('RGB')), cv2.COLOR_RGB2BGR)

    def make_navy(self):
        H, W = self.H, self.W
        yy, xx = np.mgrid[0:H, 0:W]
        r = np.sqrt(((xx - W * .5) / W) ** 2 + ((yy - H * .45) / H) ** 2)
        g = np.clip(1 - r * 1.3, 0, 1)[..., None]
        top = np.array([70, 38, 22], np.float32); bot = np.array([30, 16, 10], np.float32)   # BGR navy
        return (bot + (top - bot) * g).astype(np.uint8)

    def make_flash(self):
        H, W = self.H, self.W
        img = np.full((H, W, 3), (232, 239, 242), np.uint8)   # cream (BGR)
        rng = np.random.default_rng(11); cx, cy = W * .55, H * .5
        for k in range(70):
            a = rng.uniform(0, 2 * np.pi); r0 = rng.uniform(.18, .32) * W; r1 = W * 1.2
            w = rng.uniform(.004, .02)
            p = np.array([[cx + r0 * np.cos(a), cy + r0 * np.sin(a)],
                          [cx + r1 * np.cos(a - w), cy + r1 * np.sin(a - w)],
                          [cx + r1 * np.cos(a + w), cy + r1 * np.sin(a + w)]], np.int32)
            cv2.fillConvexPoly(img, p, (25, 22, 22), cv2.LINE_AA)
        img = cv2.GaussianBlur(img, (0, 0), 1.2)
        glow = np.zeros((H, W), np.float32); cv2.circle(glow, (int(cx), int(cy)), int(W * .2), 1.0, -1)
        glow = cv2.GaussianBlur(glow, (0, 0), W * .08)[..., None]
        return np.clip(img * (1 - glow) + 255 * glow, 0, 255).astype(np.uint8)

    def clip_frames(self, path, a, b, n, slow):
        cap = cv2.VideoCapture(path)
        fps = cap.get(cv2.CAP_PROP_FPS) or 24
        total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or int(8 * fps)
        dur = total / fps
        a = 0 if a is None else min(a, dur - 0.2); b = dur if b is None else min(b, dur)
        speed = 0.5 if slow else 1.0
        need = n / FPS * speed
        if b - a < need:   # not enough footage: slow down to at most 0.6x, then hold
            speed = max(0.6 * speed, (b - a) / (n / FPS))
        cap.set(cv2.CAP_PROP_POS_FRAMES, int(a * fps))
        src = []
        for _ in range(int((b - a) * fps) + 2):
            ok, fr = cap.read()
            if not ok: break
            src.append(fr)
        cap.release()
        if not src: return None
        out = []
        for i in range(n):
            j = min(int(i / FPS * speed * fps), len(src) - 1)
            fr = wm_cut(src[j])
            h, w = fr.shape[:2]; s = max(self.W / w, self.H / h)
            fr = cv2.resize(fr, (int(w * s + .5), int(h * s + .5)), interpolation=cv2.INTER_LINEAR)
            y0 = (fr.shape[0] - self.H) // 2; x0 = (fr.shape[1] - self.W) // 2
            out.append(fr[y0:y0 + self.H, x0:x0 + self.W])
        return out

    # ---------- GFX cards
    def gfx(self, kind, args, p, line):
        W, H = self.W, self.H
        if kind in ('title', 'stat', 'bigtext') and not self.prev_is_gfx:
            bg = cv2.GaussianBlur(self.prev_frame, (0, 0), 9)
            bg = (bg.astype(np.float32) * 0.45 + self.navy.astype(np.float32) * 0.35).astype(np.uint8)
        else:
            bg = self.navy.copy()
        img = Image.fromarray(cv2.cvtColor(bg, cv2.COLOR_BGR2RGB)).convert('RGBA')
        gold, white = (255, 200, 61, 255), (245, 242, 235, 255)
        k = ease(p * 4)
        if kind == 'title':
            l1, l2 = (args + [''])[:2]
            s1 = fit('black', int(H * 0.062), l1, W * .86, int(H * .008))
            a = int(255 * min(1, p * 5))
            draw_text(img, (W / 2, H * (0.36 + 0.02 * (1 - k))), l1, s1, (white[0], white[1], white[2], a), spacing=int(H * .008))
            sc = pop(p * 3.2)
            f2 = fit('black', max(10, int(H * 0.115 * (0.85 + 0.15 * sc))), l2, W * .9, int(H * .006))
            draw_text(img, (W / 2, H * 0.52), l2, f2, (gold[0], gold[1], gold[2], a), spacing=int(H * .006), glow=(255, 170, 40, int(160 * k)))
        elif kind == 'bigtext':
            parts = [x.strip() for x in args[0].split('·')]
            n = len(parts)
            for i, t in enumerate(parts):
                ti = ease((p - i * 0.12) * 5)
                if ti <= 0: continue
                size = int(H * (0.12 if n == 1 and len(t) < 14 else 0.085 if len(t) < 22 else 0.06))
                col = gold if (n > 1 and i == n - 1) or t.endswith('.') else white
                draw_text(img, (W / 2, H * (0.5 + (i - (n - 1) / 2) * 0.13) + 20 * (1 - ti)), t, fit('black', size, t, W * .88, int(H * .004)),
                          (col[0], col[1], col[2], int(255 * ti)), spacing=int(H * .004), glow=(255, 170, 40, 90) if col == gold else None)
        elif kind == 'stat':
            t = args[0]
            f = fit('black', int(H * 0.07 if len(t) < 26 else H * 0.052), t, W * .78)
            w, h = draw_text(Image.new('RGBA', (10, 10)), (0, 0), t, f, white, shadow=False)
            d = ImageDraw.Draw(img); bw = w + H * .12
            x0, y0 = W / 2 - bw / 2 * k, H * .5 - h - H * .05
            d.rounded_rectangle([x0, y0, W - x0, H * .5 + h + H * .05], radius=int(H * .03), fill=(14, 22, 44, 215), outline=(255, 200, 61, 255), width=max(2, H // 300))
            if k > 0.6: draw_text(img, (W / 2, H * .5), t, f, white)
        elif kind == 'number':
            a, b, unit = (args + ['0', '0', ''])[:3]
            try:
                va, vb = float(a), float(b); v = va + (vb - va) * ease(p * 1.6)
                s = f'{int(round(v)):,}'
            except ValueError: s = b
            draw_text(img, (W / 2, H * .47), s, FONTS.get('black', int(H * 0.2)), gold, glow=(255, 170, 40, 120))
            draw_text(img, (W / 2, H * .64), unit.upper(), FONTS.get('bold', int(H * 0.05)), white, spacing=int(H * .006))
        elif kind == 'list':
            items = args; n = len(items)
            for i, t in enumerate(items):
                ti = 1.0 if i < n - 1 else ease(p * 5)
                y = H * (0.5 + (i - (n - 1) / 2) * 0.14)
                col = gold if i == n - 1 else white
                draw_text(img, (W / 2 + 40 * (1 - ti), y), t, fit('black', int(H * 0.075), t, W * .86, int(H * .004)), (col[0], col[1], col[2], int(255 * ti)), spacing=int(H * .004))
        elif kind == 'chart':
            title = args[0] if args else ''
            labels = args[1:]
            d = ImageDraw.Draw(img)
            draw_text(img, (W / 2, H * .18), title.upper(), FONTS.get('bold', int(H * .045)), white, spacing=int(H * .006))
            if any('newest' in a.lower() or 'timeline' in a.lower() for a in args):
                n = 8; bw = W * .075; gap = W * .02; x0 = W / 2 - (n * bw + (n - 1) * gap) / 2
                for i in range(n):
                    fade = max(0.0, min(1.0, (ease(p * 1.3) * n - (n - 1 - i)) ))   # newest (right) fades first
                    a = int(255 * (1 - 0.92 * fade))
                    x = x0 + i * (bw + gap); y = H * .5 - bw * .4 + fade * 30
                    g = Image.new('RGBA', img.size, (0, 0, 0, 0)); gd = ImageDraw.Draw(g)
                    gd.rounded_rectangle([x, y, x + bw, y + bw * .8], radius=8, fill=(255, 200, 61, int(a * .35)), outline=(255, 210, 90, a), width=4)
                    img.alpha_composite(g)
                draw_text(img, (W * .27, H * .68), 'OLDEST', FONTS.get('bold', int(H * .035)), white, spacing=3)
                draw_text(img, (W * .73, H * .68), 'NEWEST', FONTS.get('bold', int(H * .035)), gold, spacing=3)
            else:
                x0, x1, y0, y1 = W * .2, W * .8, H * .32, H * .74
                d.line([x0, y1, x1, y1], fill=(200, 205, 220, 200), width=3); d.line([x0, y0, x0, y1], fill=(200, 205, 220, 200), width=3)
                pts = []
                for i in range(101):
                    t = i / 100
                    if t > ease(p * 1.4): break
                    yv = 1 - 0.67 * (1 - math.exp(-6 * t))
                    pts.append((x0 + (x1 - x0) * t, y1 - (y1 - y0) * yv))
                if len(pts) > 1:
                    g = Image.new('RGBA', img.size, (0, 0, 0, 0)); ImageDraw.Draw(g).line(pts, fill=(255, 190, 60, 255), width=14)
                    img.alpha_composite(g.filter(ImageFilter.GaussianBlur(10)))
                    ImageDraw.Draw(img).line(pts, fill=(255, 210, 90, 255), width=6)
                if labels and p > .2: draw_text(img, (x0 + 24, y0 - 6), labels[0], FONTS.get('semi', int(H * .035)), white, anchor='lm')
                if len(labels) > 1 and p > .6: draw_text(img, (x1 - W * .1, y1 - (y1 - y0) * .33 - H * .07), labels[1], FONTS.get('bold', int(H * .04)), gold)
        elif kind == 'terminal':
            t = args[0]; n = int(len(t) * min(1, p * 1.6))
            f = FONTS.get('mono', int(H * .06))
            draw_text(img, (W * .12, H * .5), t[:n] + ('█' if int(p * 12) % 2 == 0 else ' '), fit('mono', int(H * .06), t + 'X', W * .78), (210, 225, 255, 255), anchor='lm', glow=(120, 160, 255, 90))
        elif kind == 'endcard':
            l1, l2 = (args + [''])[:2]
            d = ImageDraw.Draw(img)
            r = int(H * .26)
            ring = Image.new('RGBA', img.size, (0, 0, 0, 0)); ImageDraw.Draw(ring).ellipse([W / 2 - r, H * .62 - r, W / 2 + r, H * .62 + r], outline=(255, 170, 60, 200), width=6)
            img.alpha_composite(ring.filter(ImageFilter.GaussianBlur(6)))
            draw_text(img, (W / 2, H * .2), l1, fit('black', int(H * .055), l1, W * .86, int(H * .006)), white, spacing=int(H * .006))
            draw_text(img, (W / 2, H * .29), l2, fit('black', int(H * .08), l2, W * .88, int(H * .005)), gold, spacing=int(H * .005), glow=(255, 170, 40, 120))
            # comment bubble, subscribe button, like
            if p > .15:
                ti = ease((p - .15) * 6); bx, by = W * .2, H * .62
                d.rounded_rectangle([bx - 110 * ti, by - 40, bx + 110 * ti, by + 40], radius=40, fill=(245, 242, 235, 255))
                if ti > .8:
                    for j in range(3): d.ellipse([bx - 30 + j * 30 - 8, by - 8, bx - 30 + j * 30 + 8, by + 8], fill=(60, 60, 70, 255))
            if p > .3:
                ti = ease((p - .3) * 6); bx, by = W * .5, H * .86
                d.rounded_rectangle([bx - 170 * ti, by - 44, bx + 170 * ti, by + 44], radius=44, fill=(229, 72, 77, 255))
                if ti > .8: draw_text(img, (bx, by), 'SUBSCRIBE', FONTS.get('black', int(H * .04)), white, spacing=3, shadow=False)
            if p > .45:
                ti = pop((p - .45) * 5); bx, by = W * .8, H * .62
                d.ellipse([bx - 55 * ti, by - 55 * ti, bx + 55 * ti, by + 55 * ti], fill=(255, 200, 61, 255))
                if ti > .7: draw_text(img, (bx, by), 'LIKE', FONTS.get('black', int(H * .028)), (40, 30, 10, 255), shadow=False)
        elif kind == 'score':
            a, b = (args + ['0', '0'])[:2]
            draw_text(img, (W / 2, H * .5), f'{a} : {b}', FONTS.get('black', int(H * .2)), white)
        else:   # unknown gfx -> bigtext of first arg
            draw_text(img, (W / 2, H * .5), (args[0] if args else line)[:40], FONTS.get('black', int(H * .08)), white)
        return cv2.cvtColor(np.array(img.convert('RGB')), cv2.COLOR_RGB2BGR)

    # ---------- overlays
    def rings(self, f, i, n=12):
        if i >= n: return f
        o = f.copy(); t = i / n
        for k in range(3):
            tk = t - k * 0.18
            if tk <= 0: continue
            r = int(self.H * (0.08 + 0.6 * tk)); a = (1 - tk) * 0.55
            cv2.circle(o, (self.W // 2, self.H // 2), r, (255, 255, 255), max(2, self.H // 360), cv2.LINE_AA)
            f = cv2.addWeighted(o, a, f, 1 - a, 0); o = f.copy()
        return f

    def pm_icon(self, f):
        if not self.pm_state: return f
        H = self.H; r = int(H * .045); pad = int(H * .1)
        img = Image.fromarray(cv2.cvtColor(f, cv2.COLOR_BGR2RGB)).convert('RGBA')
        g = Image.new('RGBA', img.size, (0, 0, 0, 0)); d = ImageDraw.Draw(g)
        if self.pm_state == 'PLUS':
            cx, cy, col = pad + r, pad + r, (255, 200, 61, 255)
            d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=col, width=max(3, H // 220))
            d.rectangle([cx - r * .5, cy - r * .12, cx + r * .5, cy + r * .12], fill=col); d.rectangle([cx - r * .12, cy - r * .5, cx + r * .12, cy + r * .5], fill=col)
        else:
            cx, cy, col = self.W - pad - r, pad + r, (150, 175, 215, 255)
            d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=col, width=max(3, H // 220))
            d.rectangle([cx - r * .5, cy - r * .12, cx + r * .5, cy + r * .12], fill=col)
        img.alpha_composite(g.filter(ImageFilter.GaussianBlur(5))); img.alpha_composite(g)
        return cv2.cvtColor(np.array(img.convert('RGB')), cv2.COLOR_RGB2BGR)

    def crack(self, a, b):
        H, W = self.H, self.W
        rng = np.random.default_rng(5)
        xs = [W // 2 + int(rng.integers(-18, 18)) for _ in range(14)]
        ys = np.linspace(0, H, 14).astype(int)
        poly_left = [(0, 0)] + [(x, y) for x, y in zip(xs, ys)] + [(0, H)]
        mask = np.zeros((H, W), np.uint8); cv2.fillPoly(mask, [np.array(poly_left, np.int32)], 255)
        out = np.where(mask[..., None] > 0, a, b)
        cv2.polylines(out, [np.array(list(zip(xs, ys)), np.int32)], False, (8, 8, 8), max(4, H // 150), cv2.LINE_AA)
        return out

    # ---------- shot renderer -> list of frames (BGR)
    def render_shot(self, sh, n):
        asset, fx = sh['asset'], set(sh['fx'])
        if 'PLUS' in fx: self.pm_state = 'PLUS'
        if 'MINUS' in fx: self.pm_state = 'MINUS'
        frames = []
        if asset.startswith('GFX:'):
            m = re.match(r'GFX:(\w+)\{(.*)\}', asset)
            kind, args = (m.group(1), [a.strip() for a in m.group(2).split(';')]) if m else ('bigtext', [asset[4:]])
            for i in range(n): frames.append(self.gfx(kind, args, i / max(1, n - 1), sh['line']))
        elif '|' in asset:   # split screen
            parts = asset.split('|')
            fa = self.static_frames(parts[0], 1, sh)[0]; fb = self.static_frames(parts[1], 1, sh)[0]
            for i in range(n):
                z = 1 + 0.03 * i / n
                A = cv2.resize(fa, None, fx=z, fy=z)[:self.H, :self.W]; B = cv2.resize(fb, None, fx=z, fy=z)[:self.H, :self.W]
                frames.append(self.crack(A, B))
        else:
            frames = self.static_frames(asset, n, sh)
        # overlays
        out = []
        prev = self.prev_frame
        for i, f in enumerate(frames):
            if 'WHIP' in fx and i < 5:
                t = (i + 1) / 6; shift = int(self.W * (1 - ease(t)))
                comp = np.zeros_like(f); comp[:, :self.W - shift] = f[:, shift:]
                if shift > 0: comp[:, self.W - shift:] = prev[:, :shift]
                k = int(9 + 70 * (1 - t)) | 1
                f = cv2.blur(comp, (k, 1))
            if 'SHAKE' in fx and i < 9:
                a = (1 - i / 9) * self.H * .014
                M = np.float32([[1, 0, random.uniform(-a, a)], [0, 1, random.uniform(-a, a)]])
                f = cv2.warpAffine(f, M, (self.W, self.H), borderMode=cv2.BORDER_REFLECT)
            if 'FLASH' in fx:
                if i == 0: f = self.flash_card.copy()
                elif i == 1: f = cv2.addWeighted(self.flash_card, 0.6, f, 0.4, 0)
            if 'RING' in fx: f = self.rings(f, i - (1 if 'FLASH' in fx else 0))
            if not asset.startswith('GFX:'): f = self.pm_icon(f)
            out.append(f)
        if 'PM-OFF' in fx: self.pm_state = None
        if out:
            if not asset.startswith('GFX:'): self.prev_frame = out[-1]
            self.prev_is_gfx = asset.startswith('GFX:') and self.prev_is_gfx_base(asset)
        return out

    def prev_is_gfx_base(self, asset):
        # after a GFX card, the next text card should not blur the old text: keep last *picture* frame instead
        return False

    def static_frames(self, code_full, n, sh):
        m = re.match(r'([IC]\d{3})(?:>(\w+))?(?:@([\d.]+)-([\d.]+))?$', code_full.strip())
        if not m: return [self.placeholder(code_full, sh['line'], 0)] * n
        code, crop, a, b = m.group(1), m.group(2) or '', m.group(3), m.group(4)
        path = self.find_asset(code)
        if code.startswith('C'):
            if path and code not in self.missing:
                fr = self.clip_frames(path, float(a) if a else None, float(b) if b else None, n, 'SLOW' in sh['fx'])
                if fr: return fr
            # fallback: use the clip's start image if known
            alt = self.clip_src.get(code)
            if alt:
                return self.static_frames(alt + (('>' + crop) if crop else ''), n, sh)
            return [self.placeholder(code_full, sh['line'], 0)] * n
        if not path:
            return [self.placeholder(code_full, sh['line'], 0)] * n
        src = self.load_img(path)
        z0, cx, cy = self.CROPS.get(crop, self.CROPS[''])
        push = 0.07 if 'PUSH' in sh['fx'] else 0.035
        frames = []
        for i in range(n):
            t = i / max(1, n - 1)
            frames.append(self.view(src, z0 * (1 + push * ease(t * 0.9 + 0.1 * t)), cx, cy))
        return frames

# ---------------------------------------------------------------- main build
def build(args):
    proj = args.proj
    voice_txt = find(proj, '02-VOICE-*[!PT].txt') or find(proj, '02-VOICE-*.txt')
    for c in sorted(glob.glob(os.path.join(proj, '02-VOICE-*.txt'))):
        if not c.endswith(('-DGT.txt', '-MAP.txt')): voice_txt = c
    blocks = parse_voice(voice_txt)
    shots = parse_shotlist(find(proj, '03-SHOTLIST-*.md'))
    vmap = parse_map(find(proj, '02-VOICE-*-MAP.txt'))
    prompts = find(proj, '04-PROMPTS-*.md')
    clip_src = {}
    if prompts:
        for m in re.finditer(r'### (C\d{3})\s+·\s+từ ảnh (I\d{3})', read(prompts)): clip_src[m.group(1)] = m.group(2)
    missing = set()
    mp = os.path.join(proj, 'missing.txt')
    if os.path.exists(mp): missing = set(re.findall(r'C\d{3}', read(mp)))
    bmap = {b['id']: b for b in blocks}
    log = []

    # ---- voice audio per block
    vfiles, mode = collect_voice_files(os.path.join(proj, 'voice'))
    audio = {}
    if not args.animatic and vfiles:
        if mode == 'named':
            for b in blocks:
                if b['id'] in vfiles: audio[b['id']] = vfiles[b['id']]
        else:
            if len(vfiles) != len(blocks): log.append(f'WARN: {len(vfiles)} voice files vs {len(blocks)} blocks — mapping by order')
            for i, f in enumerate(vfiles):
                vid = vmap.get(i + 1) or (blocks[i]['id'] if i < len(blocks) else None)
                if vid: audio[vid] = f
    vdata = {}
    for b in blocks:
        if b['id'] in audio:
            y = trim_silence(load_audio(audio[b['id']]))
            srt = os.path.splitext(audio[b['id']])[0] + '.srt'
            vdata[b['id']] = (y, srt_cues(srt))
        else:
            dur = max(0.6, len(b['text'].split()) / WORDS_PER_SEC + 0.15 * b['text'].count('...'))
            vdata[b['id']] = (None, [], dur)
            log.append(f'animatic voice {b["id"]} {dur:.2f}s')

    # ---- timeline
    t = 0.5; prev_slot = None
    shot_times = []   # (shot, start, end)
    vplace = []       # (block id, start)
    srt_items = []
    for b in blocks:
        bs = [s for s in shots if s['v'] == b['id']]
        d = vdata[b['id']]
        y = d[0]; alen = len(y) / SR if y is not None else d[2]
        gap = SPEAKER_GAP if (prev_slot and prev_slot != b['slot']) else BLOCK_GAP
        if any(s['asset'].startswith('GFX:title') for s in bs): gap = max(gap, 0.4)
        t += gap if prev_slot else 0
        start = t
        spoken = [s for s in bs if s['line'] != '—']
        offs = split_block(alen, y, [s['line'] for s in spoken], d[1] if y is not None else [])
        # minimum durations
        need_tail = 0.0
        for s in bs:
            if s['asset'].startswith('GFX:title'): need_tail = max(need_tail, 1.6)
            if s['asset'].startswith('GFX:endcard'): need_tail = max(need_tail, 4.0)
            if 'FLASH' in s['fx']: need_tail = max(need_tail, 0.2)
        if b['drop']: need_tail = max(need_tail, 0.45)
        k = 0
        for s in bs:
            if s['line'] == '—':
                shot_times.append([s, None, None]); continue
            shot_times.append([s, start + offs[k] - LEAD, None]); k += 1
        vplace.append((b['id'], start))
        # subtitles: split by spoken lines
        for j, s in enumerate(spoken):
            a0 = start + offs[j]; a1 = start + (offs[j + 1] if j + 1 < len(offs) else alen)
            srt_items.append((a0, a1, s['line']))
        t = start + alen + need_tail
        prev_slot = b['slot']
    total = t + 0.8
    # fill starts for wordless shots & compute ends
    for i, st in enumerate(shot_times):
        if st[1] is None: st[1] = shot_times[i - 1][1] + 0.8 if i else 0.0
    shot_times[0][1] = 0.0
    for i, st in enumerate(shot_times):
        st[2] = shot_times[i + 1][1] if i + 1 < len(shot_times) else total
        if st[2] - st[1] < MIN_SHOT * 0.5: log.append(f'short shot {st[0]["id"]} {st[2]-st[1]:.2f}s')

    if args.only:
        a, bb = args.only.split('-'); ids = [st[0]['id'] for st in shot_times]
        i0, i1 = ids.index(a), ids.index(bb)
        win0, win1 = shot_times[i0][1], shot_times[i1][2]
        shot_times = shot_times[i0:i1 + 1]
    else:
        win0, win1 = 0.0, total

    # ---- render video
    W, H = (960, 540) if args.preview else (1920, 1080)
    os.makedirs(args.out, exist_ok=True)
    R = Renderer(W, H, proj, missing); R.clip_src = clip_src
    look = Look(W, H)
    vid_tmp = os.path.join(args.out, '_video.mp4')
    enc = subprocess.Popen(['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'bgr24', '-s', f'{W}x{H}', '-r', str(FPS), '-i', '-',
                            '-c:v', 'libx264', '-preset', 'veryfast' if args.preview else 'medium', '-crf', '21', '-maxrate', '7M', '-bufsize', '14M', '-tune', 'animation', '-pix_fmt', 'yuv420p', vid_tmp],
                           stdin=subprocess.PIPE)
    fidx = 0; frame_t = win0; thumbs = []
    for s, a, b in shot_times:
        n = int(round((b - win0) * FPS)) - int(round((a - win0) * FPS))
        if n <= 0: continue
        frames = R.render_shot(s, n)
        thumbs.append((s['id'], cv2.resize(frames[min(len(frames) - 1, max(2, n // 2))], (320, 180))))
        for f in frames:
            enc.stdin.write(look.apply(f, fidx).tobytes()); fidx += 1
        if fidx % 240 < n: print(f'  {s["id"]}  {a:7.2f}s  frames={fidx}', flush=True)
    enc.stdin.close(); enc.wait()
    vid_len = fidx / FPS

    # ---- audio
    N = int(vid_len * SR) + SR
    voice = np.zeros(N, np.float32)
    for vid, st in vplace:
        y = vdata[vid][0]
        if y is None: continue
        i0 = int((st - win0) * SR)
        if i0 >= N or i0 + len(y) <= 0: continue
        seg = y[max(0, -i0):]; i0 = max(0, i0)
        voice[i0:i0 + len(seg)] += seg[:N - i0]
    have_voice = np.abs(voice).max() > 0
    if have_voice:
        L = lufs(voice[np.abs(voice) > 1e-4]) if np.any(np.abs(voice) > 1e-4) else -30
        voice *= 10 ** ((-16 - L) / 20)
    # music
    music = np.zeros((N, 2), np.float32)
    beds = {os.path.basename(p).split('_')[1]: p for p in glob.glob(os.path.join(args.kit, 'music', 'bed_*.wav'))}
    events = []
    for s, a, b in shot_times:
        mu = s['music'].strip()
        if not mu: continue
        if mu.startswith('bed:'): events.append((a, 'bed', mu[4:]))
        elif mu == 'DROP': events.append((a, 'drop', None))
        elif mu.startswith('RETURN:'): events.append((a, 'bed', mu[7:]))
    events.sort()
    cur_bed = None; cur_on = False
    bed_cache = {}
    def bed_audio(name):
        if name not in bed_cache and name in beds:
            y = load_stereo(beds[name]); L = lufs(y.mean(1)); bed_cache[name] = y * 10 ** ((-29 - L) / 20)
        return bed_cache.get(name)
    # build gain envelope per segment
    seg_bounds = [e[0] - win0 for e in events] + [vid_len]
    for k, (et, kind, name) in enumerate(events):
        s0 = int(max(0, et - win0) * SR); s1 = int(max(0, seg_bounds[k + 1]) * SR)
        if s1 <= s0: continue
        if kind == 'bed':
            y = bed_audio(name)
            if y is None: log.append(f'missing bed {name}'); continue
            ln = s1 - s0
            reps = int(np.ceil((ln + SR) / len(y))) + 1
            yy = np.tile(y, (reps, 1))[:ln + SR * 2]
            fade_in = int(SR * (1.2 if kind == 'bed' else 0.5))
            env = np.ones(ln + SR * 2, np.float32); env[:fade_in] = np.linspace(0, 1, fade_in)
            fo = int(SR * 1.0); env[ln:ln + fo] = np.linspace(1, 0, fo); env[ln + fo:] = 0
            e1 = min(N, s0 + len(yy)); music[s0:e1] += (yy * env[:, None])[:e1 - s0]
    # sfx
    sfxd = os.path.join(args.kit, 'sfx'); sfx = np.zeros((N, 2), np.float32)
    sfx_cache = {}
    def sfx_audio(name):
        if name not in sfx_cache:
            g = glob.glob(os.path.join(sfxd, name + '*.wav'))
            if not g: sfx_cache[name] = None
            else:
                y = load_stereo(g[0]); pk = np.abs(y).max() + 1e-9
                hit = 0.0
                mm = re.search(r'hitAt(\d+)ms', g[0])
                if mm: hit = int(mm.group(1)) / 1000
                sfx_cache[name] = (y / pk, hit)
        return sfx_cache[name]
    sfx_gain = {'whoosh': 0.32, 'flash_hit': 0.55, 'impact': 0.45, 'slowmo': 0.35, 'riser': 0.3, 'heartbeat': 0.5, 'crowd': 0.25,
                'tick': 0.25, 'pop': 0.3, 'ding': 0.3, 'ting': 0.3, 'glitch': 0.25, 'downer': 0.35, 'cash': 0.3, 'thud': 0.4, 'type': 0.25, 'terminal': 0.25, 'phone': 0.35}
    for s, a, b in shot_times:
        for name in [x.strip() for x in s['sfx'].split('+') if x.strip()]:
            if name.startswith('foley:'): log.append(f'{s["id"]} foley skipped: {name}'); continue
            r = sfx_audio(name)
            if r is None: log.append(f'{s["id"]} sfx not found: {name}'); continue
            y, hit = r
            g = next((v for k, v in sfx_gain.items() if name.startswith(k)), 0.3)
            st = a - win0 - hit
            if name.startswith('whoosh'): st -= 0.12
            i0 = int(st * SR)
            if i0 < 0: y = y[-i0:]; i0 = 0
            e1 = min(N, i0 + len(y)); sfx[i0:e1] += y[:e1 - i0] * g
    mix = music + sfx + voice[:, None] * (1.0 if have_voice else 0)
    L = lufs(mix)
    mix *= 10 ** ((-14 - L) / 20)
    mix = np.tanh(mix * 1.2) / 1.2                     # gentle soft-clip of rare peaks
    L = lufs(mix); mix *= 10 ** ((-14 - L) / 20)
    pk = np.abs(mix).max()
    if pk > 0.89: mix *= 0.89 / pk                      # keep true peak under ~-1 dBFS
    wav = os.path.join(args.out, '_mix.wav'); sf.write(wav, mix[:int(vid_len * SR)], SR, subtype='PCM_16')

    final = os.path.join(args.out, args.name + ('_preview' if args.preview else '') + '.mp4')
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', vid_tmp, '-i', wav, '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-shortest', final], check=True)
    os.remove(vid_tmp); os.remove(wav)

    # ---- srt, timeline, contact sheet
    def ts(x):
        x = max(0, x); h = int(x // 3600); m = int(x % 3600 // 60); s = x % 60
        return f'{h:02d}:{m:02d}:{int(s):02d},{int(round((s - int(s)) * 1000)):03d}'
    with open(os.path.join(args.out, args.name + '.srt'), 'w', encoding='utf-8') as f:
        for i, (a0, a1, txt) in enumerate(srt_items):
            if a1 < win0 or a0 > win1: continue
            f.write(f'{i + 1}\n{ts(a0 - win0)} --> {ts(a1 - win0)}\n{txt}\n\n')
    json.dump([dict(id=s['id'], v=s['v'], start=round(a, 3), end=round(b, 3), asset=s['asset'], fx=s['fx']) for s, a, b in shot_times],
              open(os.path.join(args.out, 'timeline.json'), 'w'), indent=1)
    cols = 8; rows_ = int(np.ceil(len(thumbs) / cols))
    for page in range(0, rows_, 6):
        chunk = thumbs[page * cols:(page + 6) * cols]
        sheet = np.zeros((6 * 200, cols * 320, 3), np.uint8)
        for j, (sid, im) in enumerate(chunk):
            r, c = divmod(j, cols); sheet[r * 200:r * 200 + 180, c * 320:(c + 1) * 320] = im
            cv2.putText(sheet, sid, (c * 320 + 4, r * 200 + 196), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
        cv2.imwrite(os.path.join(args.out, f'qc_sheet_{page // 6 + 1:02d}.jpg'), sheet, [cv2.IMWRITE_JPEG_QUALITY, 80])
    with open(os.path.join(args.out, 'build_log.txt'), 'w', encoding='utf-8') as f:
        f.write(f'video {vid_len:.1f}s, shots {len(shot_times)}, frames {fidx}\n' + '\n'.join(log) + '\n')
    if args.split:
        size = os.path.getsize(final); part = int(args.split * 1024 * 1024)
        if size > part:
            names = []
            with open(final, 'rb') as fin:
                k = 1
                while True:
                    chunk = fin.read(part)
                    if not chunk: break
                    pn = f'{os.path.basename(final)}.part{k:02d}'; names.append(pn)
                    open(os.path.join(args.out, pn), 'wb').write(chunk); k += 1
            bat = 'copy /b ' + '+'.join(f'"{n}"' for n in names) + f' "{os.path.basename(final)}"\r\ndel ' + ' '.join(f'"{n}"' for n in names) + '\r\n'
            open(os.path.join(args.out, 'GHEP-VIDEO.bat'), 'w', newline='').write('@echo off\r\ncd /d "%~dp0"\r\n' + bat + 'echo Xong! Video: ' + os.path.basename(final) + '\r\npause\r\n')
            print('split into', len(names), 'parts')
    print(f'DONE {final}  {vid_len:.1f}s  shots={len(shot_times)}')
    return final

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--proj', required=True); ap.add_argument('--kit', required=True); ap.add_argument('--out', required=True)
    ap.add_argument('--name', default='final'); ap.add_argument('--preview', action='store_true')
    ap.add_argument('--animatic', action='store_true'); ap.add_argument('--only', default='')
    ap.add_argument('--wm-keep', type=float, default=0.90)
    ap.add_argument('--split', type=float, default=0, help='split final mp4 into N-MB parts + GHEP-VIDEO.bat (Windows)')
    a = ap.parse_args(); WM_KEEP = a.wm_keep; build(a)
